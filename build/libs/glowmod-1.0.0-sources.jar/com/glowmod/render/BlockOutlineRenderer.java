package com.glowmod.render;

import com.glowmod.GlowConfig;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7923;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BlockOutlineRenderer {

    private static int refreshTimer = 0;

    private static final Map<Long, Map<class_2338, Integer>> blocksByChunk = new ConcurrentHashMap<>();
    private static final Map<Long, class_2818>             loadedChunks  = new ConcurrentHashMap<>();

    // Set instead of Queue: O(1) add with built-in deduplication — no contains() scan needed.
    private static final Set<Long> scanQueue = ConcurrentHashMap.newKeySet();

    // Pre-computed Block → color map rebuilt whenever the whitelist changes.
    // Avoids registry reverse-lookups and string allocations inside the hot scan loop.
    private static final Map<class_2248, Integer> blockColorLookup = new HashMap<>();

    private static final RenderPipeline FILLED_NO_DEPTH_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(class_10799.field_56860)
                    .withLocation(class_2960.method_60655("glowmod", "pipeline/filled_no_depth"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build()
    );

    private static final class_1921 FILLED_NO_DEPTH_LAYER = class_1921.method_75940(
            "glowmod_filled_no_depth",
            class_12247.method_75927(FILLED_NO_DEPTH_PIPELINE)
                    .method_75930(class_12245.field_63976)
                    .method_75931(class_12246.field_63980)
                    .method_75938()
    );

    public static void init() {
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            long key = chunk.method_12004().method_8324();
            loadedChunks.put(key, chunk);
            if (!GlowConfig.blockWhitelist.isEmpty()) scanQueue.add(key);
        });

        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> {
            long key = chunk.method_12004().method_8324();
            loadedChunks.remove(key);
            blocksByChunk.remove(key);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || GlowConfig.blockWhitelist.isEmpty()) return;

            refreshTimer++;
            if (refreshTimer >= GlowConfig.chunkRefreshInterval) {
                refreshTimer = 0;
                // addAll is O(n) with O(1) per key — no O(n) contains scan, no spike.
                scanQueue.addAll(loadedChunks.keySet());
            }

            int processed = 0;
            Iterator<Long> it = scanQueue.iterator();
            while (processed < GlowConfig.chunkScanRate && it.hasNext()) {
                Long key = it.next();
                it.remove();
                class_2818 chunk = loadedChunks.get(key);
                if (chunk != null) scanChunk(chunk);
                processed++;
            }
        });

        rebuildBlockLookup();

        WorldRenderEvents.END_MAIN.register(context -> {
            if (!GlowConfig.blockOutlineEnabled || blocksByChunk.isEmpty()) return;

            class_243 cam = context.gameRenderer().method_19418().method_71156();
            class_4587 poseStack = context.matrices();
            class_4588 buffer = context.consumers().method_73477(FILLED_NO_DEPTH_LAYER);

            poseStack.method_22903();
            poseStack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);

            double cullRadSq = 256.0 * 256.0;

            for (Map<class_2338, Integer> posColors : blocksByChunk.values()) {
                for (Map.Entry<class_2338, Integer> entry : posColors.entrySet()) {
                    class_2338 pos = entry.getKey();
                    double dx = pos.method_10263() + 0.5 - cam.field_1352;
                    double dy = pos.method_10264() + 0.5 - cam.field_1351;
                    double dz = pos.method_10260() + 0.5 - cam.field_1350;
                    if (dx*dx + dy*dy + dz*dz > cullRadSq) continue;

                    int color = entry.getValue();
                    float r = ((color >> 16) & 0xFF) / 255f;
                    float g = ((color >> 8)  & 0xFF) / 255f;
                    float b = (color & 0xFF) / 255f;
                    float a = GlowConfig.outlineOpacity;
                    renderFilledBox(poseStack, buffer,
                            new class_238(pos.method_10263(), pos.method_10264(), pos.method_10260(),
                                    pos.method_10263() + 1, pos.method_10264() + 1, pos.method_10260() + 1).method_1014(0.0015),
                            r, g, b, a);
                }
            }

            poseStack.method_22909();
            ((net.minecraft.class_4597.class_4598) context.consumers()).method_22993();
        });
    }

    public static void rescanAll() {
        blocksByChunk.clear();
        scanQueue.clear();
        rebuildBlockLookup();
        if (GlowConfig.blockWhitelist.isEmpty()) return;
        scanQueue.addAll(loadedChunks.keySet());
    }

    private static void rebuildBlockLookup() {
        blockColorLookup.clear();
        for (Map.Entry<String, Integer> entry : GlowConfig.blockWhitelist.entrySet()) {
            if (GlowConfig.disabledBlocks.contains(entry.getKey())) continue;
            class_2960 id = class_2960.method_12829(entry.getKey());
            if (id == null) continue;
            class_2248 b = class_7923.field_41175.method_63535(id);
            if (b != null) blockColorLookup.put(b, entry.getValue());
        }
    }

    private static void scanChunk(class_2818 chunk) {
        if (blockColorLookup.isEmpty()) {
            blocksByChunk.remove(chunk.method_12004().method_8324());
            return;
        }

        int minY      = chunk.method_31607();
        int chunkMinX = chunk.method_12004().method_8326();
        int chunkMinZ = chunk.method_12004().method_8328();
        Map<class_2338, Integer> found = new HashMap<>();

        for (int sectionIdx = 0; sectionIdx < chunk.method_32890(); sectionIdx++) {
            class_2826 section = chunk.method_38259(sectionIdx);
            if (section.method_38292()) continue;

            int sectionMinY = minY + sectionIdx * 16;

            for (int ly = 0; ly < 16; ly++) {
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        class_2248 block = section.method_12254(lx, ly, lz).method_26204();
                        Integer color = blockColorLookup.get(block);
                        if (color != null) {
                            found.put(new class_2338(chunkMinX + lx, sectionMinY + ly, chunkMinZ + lz), color);
                        }
                    }
                }
            }
        }

        if (!found.isEmpty()) blocksByChunk.put(chunk.method_12004().method_8324(), found);
        else blocksByChunk.remove(chunk.method_12004().method_8324());
    }

    private static void renderFilledBox(class_4587 poseStack, class_4588 buffer, class_238 box, float r, float g, float b, float a) {
        class_4587.class_4665 pose = poseStack.method_23760();
        float x1 = (float)box.field_1323, y1 = (float)box.field_1322, z1 = (float)box.field_1321;
        float x2 = (float)box.field_1320, y2 = (float)box.field_1325, z2 = (float)box.field_1324;
        // bottom
        buffer.method_56824(pose, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y1, z2).method_22915(r, g, b, a);
        // top
        buffer.method_56824(pose, x1, y2, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y2, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y2, z1).method_22915(r, g, b, a);
        // north (z=z1)
        buffer.method_56824(pose, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y2, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y1, z1).method_22915(r, g, b, a);
        // south (z=z2)
        buffer.method_56824(pose, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y1, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y2, z2).method_22915(r, g, b, a);
        // west (x=x1)
        buffer.method_56824(pose, x1, y1, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y1, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y2, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x1, y2, z1).method_22915(r, g, b, a);
        // east (x=x2)
        buffer.method_56824(pose, x2, y1, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y2, z1).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y2, z2).method_22915(r, g, b, a);
        buffer.method_56824(pose, x2, y1, z2).method_22915(r, g, b, a);
    }
}
