package com.glowmod.render;

import com.glowmod.GlowConfig;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientChunkEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.class_10799;
import net.minecraft.class_12245;
import net.minecraft.class_12246;
import net.minecraft.class_12247;
import net.minecraft.class_1921;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2818;
import net.minecraft.class_2826;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_7923;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

public class BlockOutlineRenderer {

    private static final int CHUNKS_PER_TICK = 3;

    private static final Map<Long, Map<class_2338, Integer>> blocksByChunk = new ConcurrentHashMap<>();
    private static final Map<Long, class_2818> loadedChunks              = new ConcurrentHashMap<>();
    private static final Queue<Long> scanQueue                           = new ConcurrentLinkedQueue<>();

    private static final RenderPipeline LINES_NO_DEPTH_PIPELINE = class_10799.method_67887(
            RenderPipeline.builder(class_10799.field_56859)
                    .withLocation(class_2960.method_60655("glowmod", "pipeline/lines_no_depth"))
                    .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                    .build()
    );

    private static final class_1921 LINES_NO_DEPTH_LAYER = class_1921.method_75940(
            "glowmod_lines_no_depth",
            class_12247.method_75927(LINES_NO_DEPTH_PIPELINE)
                    .method_75930(class_12245.field_63976)
                    .method_75931(class_12246.field_63980)
                    .method_75938()
    );

    public static void init() {
        ClientChunkEvents.CHUNK_LOAD.register((world, chunk) -> {
            long key = chunk.method_12004().method_8324();
            loadedChunks.put(key, chunk);
            if (!GlowConfig.blockWhitelist.isEmpty()) scanQueue.offer(key);
        });

        ClientChunkEvents.CHUNK_UNLOAD.register((world, chunk) -> {
            long key = chunk.method_12004().method_8324();
            loadedChunks.remove(key);
            blocksByChunk.remove(key);
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.field_1687 == null || GlowConfig.blockWhitelist.isEmpty()) return;
            int processed = 0;
            while (processed < CHUNKS_PER_TICK) {
                Long key = scanQueue.poll();
                if (key == null) break;
                class_2818 chunk = loadedChunks.get(key);
                if (chunk != null) scanChunk(chunk);
                processed++;
            }
        });

        WorldRenderEvents.END_MAIN.register(context -> {
            if (!GlowConfig.blockOutlineEnabled || blocksByChunk.isEmpty()) return;

            class_243 cam = context.gameRenderer().method_19418().method_71156();
            class_4587 poseStack = context.matrices();
            class_4588 buffer = context.consumers().method_73477(LINES_NO_DEPTH_LAYER);

            poseStack.method_22903();
            poseStack.method_22904(-cam.field_1352, -cam.field_1351, -cam.field_1350);

            for (Map<class_2338, Integer> posColors : blocksByChunk.values()) {
                for (Map.Entry<class_2338, Integer> entry : posColors.entrySet()) {
                    class_2338 pos = entry.getKey();
                    int color = entry.getValue();
                    float r = ((color >> 16) & 0xFF) / 255f;
                    float g = ((color >> 8)  & 0xFF) / 255f;
                    float b = (color & 0xFF) / 255f;
                    renderBox(poseStack, buffer,
                            new class_238(pos.method_10263(), pos.method_10264(), pos.method_10260(),
                                    pos.method_10263() + 1, pos.method_10264() + 1, pos.method_10260() + 1).method_1014(0.0015),
                            r, g, b);
                }
            }

            poseStack.method_22909();
            ((net.minecraft.class_4597.class_4598) context.consumers()).method_22993();
        });
    }

    public static void rescanAll() {
        blocksByChunk.clear();
        scanQueue.clear();
        if (GlowConfig.blockWhitelist.isEmpty()) return;
        scanQueue.addAll(loadedChunks.keySet());
    }

    private static void scanChunk(class_2818 chunk) {
        if (GlowConfig.blockWhitelist.isEmpty()) {
            blocksByChunk.remove(chunk.method_12004().method_8324());
            return;
        }

        int minY      = chunk.method_31607();
        int chunkMinX = chunk.method_12004().method_8326();
        int chunkMinZ = chunk.method_12004().method_8328();
        Map<class_2338, Integer> found = new HashMap<>();

        for (int sectionIdx = 0; sectionIdx < chunk.method_32890(); sectionIdx++) {
            class_2826 section = chunk.method_38259(sectionIdx);
            if (section.method_38292()) continue;

            int sectionMinY = minY + sectionIdx * 16;

            for (int ly = 0; ly < 16; ly++) {
                for (int lx = 0; lx < 16; lx++) {
                    for (int lz = 0; lz < 16; lz++) {
                        class_2248 block = section.method_12254(lx, ly, lz).method_26204();
                        class_2960 key = class_7923.field_41175.method_10221(block);
                        if (key == null) continue;
                        Integer color = GlowConfig.blockWhitelist.get(key.toString());
                        if (color != null) {
                            found.put(new class_2338(chunkMinX + lx, sectionMinY + ly, chunkMinZ + lz), color);
                        }
                    }
                }
            }
        }

        if (!found.isEmpty()) blocksByChunk.put(chunk.method_12004().method_8324(), found);
        else blocksByChunk.remove(chunk.method_12004().method_8324());
    }

    private static void renderBox(class_4587 poseStack, class_4588 buffer, class_238 box, float r, float g, float b) {
        double x1 = box.field_1323, y1 = box.field_1322, z1 = box.field_1321;
        double x2 = box.field_1320, y2 = box.field_1325, z2 = box.field_1324;
        addLine(poseStack, buffer, x1, y1, z1, x2, y1, z1, r, g, b);
        addLine(poseStack, buffer, x1, y1, z2, x2, y1, z2, r, g, b);
        addLine(poseStack, buffer, x1, y1, z1, x1, y1, z2, r, g, b);
        addLine(poseStack, buffer, x2, y1, z1, x2, y1, z2, r, g, b);
        addLine(poseStack, buffer, x1, y2, z1, x2, y2, z1, r, g, b);
        addLine(poseStack, buffer, x1, y2, z2, x2, y2, z2, r, g, b);
        addLine(poseStack, buffer, x1, y2, z1, x1, y2, z2, r, g, b);
        addLine(poseStack, buffer, x2, y2, z1, x2, y2, z2, r, g, b);
        addLine(poseStack, buffer, x1, y1, z1, x1, y2, z1, r, g, b);
        addLine(poseStack, buffer, x2, y1, z1, x2, y2, z1, r, g, b);
        addLine(poseStack, buffer, x1, y1, z2, x1, y2, z2, r, g, b);
        addLine(poseStack, buffer, x2, y1, z2, x2, y2, z2, r, g, b);
    }

    private static void addLine(class_4587 poseStack, class_4588 buffer,
                                 double x1, double y1, double z1,
                                 double x2, double y2, double z2,
                                 float r, float g, float b) {
        class_4587.class_4665 pose = poseStack.method_23760();
        float dx = (float)(x2-x1), dy = (float)(y2-y1), dz = (float)(z2-z1);
        float len = (float) Math.sqrt(dx*dx + dy*dy + dz*dz);
        if (len < 1e-6f) return;
        buffer.method_56824(pose, (float)x1, (float)y1, (float)z1).method_22915(r,g,b,1f).method_60831(pose,dx/len,dy/len,dz/len).method_75298(2.5f);
        buffer.method_56824(pose, (float)x2, (float)y2, (float)z2).method_22915(r,g,b,1f).method_60831(pose,dx/len,dy/len,dz/len).method_75298(2.5f);
    }
}
