package com.glowmod.render;

import net.minecraft.class_332;

public class GuiRenderer {

    public static void roundedRect(class_332 g, float x, float y, float w, float h, float radius, int argb) {
        g.method_25294((int)x, (int)y, (int)(x + w), (int)(y + h), argb);
    }

    public static void shadow(class_332 g, float x, float y, float w, float h, float radius, int steps) {
        for (int i = steps; i >= 1; i--) {
            float ex    = i * 1.4f;
            int   alpha = Math.max(0, (int)(50f * (1f - (float)i / (steps + 1))));
            g.method_25294((int)(x - ex),       (int)(y - ex * 0.2f + ex * 0.7f),
                   (int)(x + w + ex * 2), (int)(y + h + ex * 2), alpha << 24);
        }
    }
}
