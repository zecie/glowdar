package com.glowmod.mixin;

import com.glowmod.GlowConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class EntityGlowMixin {

    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true)
    private void onIsCurrentlyGlowing(CallbackInfoReturnable<Boolean> cir) {
        class_1297 self = (class_1297) (Object) this;
        if (!self.method_73183().method_8608()) return;

        if (self instanceof class_1657) {
            if (!GlowConfig.playerGlowEnabled) return;
            if (self == class_310.method_1551().field_1724) return;
            cir.setReturnValue(true);
            return;
        }

        if (self instanceof class_1308 && GlowConfig.mobGlowEnabled && !GlowConfig.mobGlowWhitelist.isEmpty()) {
            class_2960 id = class_7923.field_41177.method_10221(self.method_5864());
            if (id != null && GlowConfig.mobGlowWhitelist.contains(id.toString())) {
                cir.setReturnValue(true);
            }
        }
    }

    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void onGetTeamColor(CallbackInfoReturnable<Integer> cir) {
        class_1297 self = (class_1297) (Object) this;
        if (!self.method_73183().method_8608()) return;

        if (self instanceof class_1657) {
            if (!GlowConfig.playerGlowEnabled) return;
            if (self == class_310.method_1551().field_1724) return;
            cir.setReturnValue(GlowConfig.playerGlowColor);
            return;
        }

        if (self instanceof class_1308 && GlowConfig.mobGlowEnabled && !GlowConfig.mobGlowWhitelist.isEmpty()) {
            class_2960 id = class_7923.field_41177.method_10221(self.method_5864());
            if (id != null && GlowConfig.mobGlowWhitelist.contains(id.toString())) {
                cir.setReturnValue(GlowConfig.mobGlowColor);
            }
        }
    }
}
