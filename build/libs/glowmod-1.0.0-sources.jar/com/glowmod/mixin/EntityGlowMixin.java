package com.glowmod.mixin;

import com.glowmod.EntityGlowManager;
import com.glowmod.GlowConfig;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1297.class)
public class EntityGlowMixin {

    @Inject(method = "isCurrentlyGlowing", at = @At("HEAD"), cancellable = true)
    private void onIsCurrentlyGlowing(CallbackInfoReturnable<Boolean> cir) {
        class_1297 self = (class_1297)(Object)this;
        if (!self.method_73183().method_8608()) return;
        if (EntityGlowManager.shouldGlow(self.method_5628())) cir.setReturnValue(true);
    }

    @Inject(method = "getTeamColor", at = @At("HEAD"), cancellable = true)
    private void onGetTeamColor(CallbackInfoReturnable<Integer> cir) {
        class_1297 self = (class_1297)(Object)this;
        if (!self.method_73183().method_8608()) return;
        if (!EntityGlowManager.shouldGlow(self.method_5628())) return;

        if (self instanceof class_1657 && GlowConfig.playerGlowEnabled) {
            cir.setReturnValue(GlowConfig.playerGlowColor);
        } else if (self instanceof class_1308 && GlowConfig.mobGlowEnabled) {
            cir.setReturnValue(GlowConfig.mobGlowColor);
        }
    }
}
