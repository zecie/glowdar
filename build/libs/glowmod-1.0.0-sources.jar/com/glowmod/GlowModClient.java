package com.glowmod;

import com.glowmod.EntityGlowManager;
import com.glowmod.render.BlockOutlineRenderer;
import com.glowmod.screen.BlockWhitelistScreen;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import org.lwjgl.glfw.GLFW;

public class GlowModClient implements ClientModInitializer {

    public static class_304 openGuiKey;

    @Override
    public void onInitializeClient() {
        GlowConfig.load();
        BlockOutlineRenderer.init();
        EntityGlowManager.init();

        openGuiKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.glowmod.open_gui",
                GLFW.GLFW_KEY_G,
                class_304.class_11900.field_62556
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (openGuiKey.method_1436()) {
                client.method_1507(new BlockWhitelistScreen(client.field_1755));
            }
        });
    }
}
