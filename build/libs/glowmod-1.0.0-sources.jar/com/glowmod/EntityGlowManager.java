package com.glowmod;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1308;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import java.util.*;

public class EntityGlowManager {

    // Written on the tick thread, read on the render thread.
    // Volatile + immutable-after-publish makes this safe without locking.
    private static volatile Set<Integer> glowSet = Collections.emptySet();

    private record Candidate(int id, double distSq) {}

    public static void init() {
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.field_1687 == null || mc.field_1724 == null) {
                glowSet = Collections.emptySet();
                return;
            }

            boolean wantPlayers = GlowConfig.playerGlowEnabled;
            boolean wantMobs    = GlowConfig.mobGlowEnabled && !GlowConfig.mobGlowWhitelist.isEmpty();
            if (!wantPlayers && !wantMobs) {
                glowSet = Collections.emptySet();
                return;
            }

            double range   = GlowConfig.glowRange;
            double rangeSq = range * range;
            class_243   center  = mc.field_1724.method_73189();
            class_238   box     = new class_238(
                    center.field_1352 - range, center.field_1351 - range, center.field_1350 - range,
                    center.field_1352 + range, center.field_1351 + range, center.field_1350 + range);

            List<Candidate> candidates = new ArrayList<>();

            if (wantPlayers) {
                for (class_1657 p : mc.field_1687.method_18467(class_1657.class, box)) {
                    if (p == mc.field_1724) continue;
                    double d = p.method_5858(mc.field_1724);
                    if (d <= rangeSq) candidates.add(new Candidate(p.method_5628(), d));
                }
            }

            if (wantMobs) {
                for (class_1308 mob : mc.field_1687.method_18467(class_1308.class, box)) {
                    class_2960 id = class_7923.field_41177.method_10221(mob.method_5864());
                    if (id == null) continue;
                    String idStr = id.toString();
                    if (!GlowConfig.mobGlowWhitelist.contains(idStr)) continue;
                    if (GlowConfig.disabledMobs.contains(idStr)) continue;
                    double d = mob.method_5858(mc.field_1724);
                    if (d <= rangeSq) candidates.add(new Candidate(mob.method_5628(), d));
                }
            }

            // Sort by distance so the closest entities always win when at the cap.
            candidates.sort(Comparator.comparingDouble(Candidate::distSq));

            int cap = GlowConfig.maxGlowEntities;
            Set<Integer> next = new HashSet<>(Math.min(candidates.size(), cap) * 2 + 1);
            for (int i = 0; i < candidates.size() && i < cap; i++) {
                next.add(candidates.get(i).id());
            }
            glowSet = next;
        });
    }

    public static boolean shouldGlow(int entityId) {
        return glowSet.contains(entityId);
    }
}
