package com.glowmod.screen;

import com.glowmod.GlowConfig;
import com.glowmod.GlowModClient;
import com.glowmod.render.BlockOutlineRenderer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_11908;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_3675;
import net.minecraft.class_437;
import net.minecraft.class_7923;
import org.lwjgl.glfw.GLFW;

import java.util.*;
import java.util.stream.StreamSupport;

public class BlockWhitelistScreen extends class_437 {

    private static final int MAX_RES = 16;
    private static final int ROW_H   = 16;
    private static final int FEAT_H  = 28;
    private static final int PILL_W  = 32;
    private static final int PILL_H  = 14;
    private static final int SWATCH  = 10;
    private static final int PAD     = 16;

    // GitHub Dark palette
    private static final int C_DIM     = 0xB0000000;
    private static final int C_BG      = 0xFF0D1117;
    private static final int C_HEADER  = 0xFF161B22;
    private static final int C_SURFACE = 0xFF161B22;
    private static final int C_BORDER  = 0xFF30363D;
    private static final int C_TEXT    = 0xFFE6EDF3;
    private static final int C_MUTED   = 0xFF7D8590;
    private static final int C_DIM_TXT = 0xFF484F58;
    private static final int C_ACCENT  = 0xFF2F81F7;
    private static final int C_GREEN   = 0xFF3FB950;
    private static final int C_RED     = 0xFFF85149;
    private static final int C_HOV     = 0x0CFFFFFF;
    private static final int C_SEL     = 0x16FFFFFF;

    private static final int PK_SIZE  = 120;
    private static final int PK_HUE_H = 12;
    private static final int PK_PAD   = 12;
    private static final int PK_W     = PK_SIZE + PK_PAD * 2;
    private static final int PK_H     = PK_PAD + PK_SIZE + PK_PAD + PK_HUE_H + PK_PAD + 12 + PK_PAD;

    private final class_437 parent;
    private class_342 searchBox;
    private boolean mobMode = false;

    private List<class_2248>         blockResults   = new ArrayList<>();
    private List<class_1299<?>> mobResults     = new ArrayList<>();
    private List<String>        whitelistCache = new ArrayList<>();
    private Map<String, String>  nameCache     = new LinkedHashMap<>();
    private Map<String, Integer> colorCache    = new LinkedHashMap<>();
    private int  selectedResult = 0;
    private int  listScroll     = 0;
    private boolean capturingKey = false;

    private float animPlayer  = 0f;
    private float animMob     = 0f;
    private float animOutline = 0f;

    private String  pickerTarget = null;
    private float   pickerH = 0f, pickerS = 1f, pickerV = 1f;
    private int     pkX, pkY;
    private boolean dragSV = false, dragHue = false;

    private int px, py, pw, ph;
    private int headerH, featSectionY, featSectionH;
    private int tabY, tabH, contentY, contentH;
    private int splitX, footerY, footerH;

    private int rowPlayerY, rowMobY, rowOutlineY;
    private int swatchPlayerX, swatchMobX;
    private int keyBtnX, keyBtnW, keyBtnY;

    public BlockWhitelistScreen(class_437 parent) {
        super(class_2561.method_43473());
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        pw = Math.min(560, field_22789  - 80);
        ph = Math.min(400, field_22790 - 80);
        px = (field_22789  - pw) / 2;
        py = (field_22790 - ph) / 2;

        headerH      = 46;
        featSectionY = py + headerH;
        featSectionH = FEAT_H * 3;
        tabY         = featSectionY + featSectionH;
        tabH         = 22;
        footerH      = 30;
        footerY      = py + ph - footerH;
        contentY     = tabY + tabH;
        contentH     = footerY - contentY;
        splitX       = px + pw / 2;

        animPlayer  = GlowConfig.playerGlowEnabled  ? 1f : 0f;
        animMob     = GlowConfig.mobGlowEnabled      ? 1f : 0f;
        animOutline = GlowConfig.blockOutlineEnabled ? 1f : 0f;

        rebuildCache();

        searchBox = new class_342(field_22793, px + PAD + 6, contentY + 9, splitX - px - PAD * 2 - 12, 10, class_2561.method_43473());
        searchBox.method_1880(100);
        searchBox.method_1858(false);
        searchBox.method_1863(q -> { selectedResult = 0; refreshResults(q); });
        method_25429(searchBox);
        method_48265(searchBox);
    }

    @Override
    public void method_25420(class_332 g, int mx, int my, float delta) {
        g.method_25294(0, 0, field_22789, field_22790, C_DIM);
    }

    @Override
    public void method_25394(class_332 g, int mx, int my, float delta) {
        float step = delta * 0.3f;
        animPlayer  += ((GlowConfig.playerGlowEnabled  ? 1f : 0f) - animPlayer)  * step;
        animMob     += ((GlowConfig.mobGlowEnabled      ? 1f : 0f) - animMob)     * step;
        animOutline += ((GlowConfig.blockOutlineEnabled ? 1f : 0f) - animOutline) * step;

        super.method_25394(g, mx, my, delta);

        // ── card shell ─────────────────────────────────────────────────────
        // offset shadow (2px down-right, dark)
        g.method_25294(px + 3, py + 3, px + pw + 3, py + ph + 3, 0x55000000);
        g.method_25294(px + 2, py + 2, px + pw + 2, py + ph + 2, 0x33000000);
        // border
        g.method_25294(px - 1, py - 1, px + pw + 1, py + ph + 1, C_BORDER);
        // card fill
        g.method_25294(px, py, px + pw, py + ph, C_BG);

        // ── header ─────────────────────────────────────────────────────────
        g.method_25294(px, py, px + pw, py + headerH, C_HEADER);
        // header bottom border
        g.method_25294(px, py + headerH, px + pw, py + headerH + 1, C_BORDER);

        // title
        g.method_51433(field_22793, "GlowMod", px + PAD, py + (headerH - 8) / 2, C_TEXT, false);

        // key binding button
        String kLabel = capturingKey ? "press a key..." : keyName();
        keyBtnW = field_22793.method_1727(kLabel) + 14;
        keyBtnX = px + pw - keyBtnW - 10;
        keyBtnY = py + (headerH - 16) / 2;
        boolean kHov = mx >= keyBtnX && mx < keyBtnX + keyBtnW && my >= keyBtnY && my < keyBtnY + 16;
        g.method_25294(keyBtnX - 1, keyBtnY - 1, keyBtnX + keyBtnW + 1, keyBtnY + 17, C_BORDER);
        g.method_25294(keyBtnX, keyBtnY, keyBtnX + keyBtnW, keyBtnY + 16, kHov ? 0xFF1C2128 : 0xFF0D1117);
        g.method_51433(field_22793, kLabel, keyBtnX + 7, keyBtnY + 4, capturingKey ? C_ACCENT : C_MUTED, false);

        // ── feature section ─────────────────────────────────────────────────
        g.method_25294(px, featSectionY, px + pw, featSectionY + featSectionH, C_SURFACE);
        g.method_25294(px, featSectionY + featSectionH, px + pw, featSectionY + featSectionH + 1, C_BORDER);

        rowPlayerY  = featSectionY;
        rowMobY     = featSectionY + FEAT_H;
        rowOutlineY = featSectionY + FEAT_H * 2;

        renderFeatureRow(g, mx, my, rowPlayerY,  "Player Glow",    animPlayer,  GlowConfig.playerGlowEnabled,  GlowConfig.playerGlowColor, "playerGlow");
        renderFeatureRow(g, mx, my, rowMobY,     "Mob Glow",       animMob,     GlowConfig.mobGlowEnabled,     GlowConfig.mobGlowColor,    "mobGlow");
        renderFeatureRow(g, mx, my, rowOutlineY, "Block Outlines", animOutline, GlowConfig.blockOutlineEnabled, -1,                         null);

        // ── tabs ────────────────────────────────────────────────────────────
        g.method_25294(px, tabY, px + pw, tabY + tabH, C_BG);
        g.method_25294(px, tabY + tabH, px + pw, tabY + tabH + 1, C_BORDER);
        String[] tabs = {"blocks", "mobs"};
        int tx = px + PAD;
        for (int i = 0; i < tabs.length; i++) {
            boolean active = (i == 1) == mobMode;
            int tw = field_22793.method_1727(tabs[i]) + 16;
            boolean hov = mx >= tx && mx < tx + tw && my >= tabY && my < tabY + tabH;
            if (active)   g.method_25294(tx, tabY, tx + tw, tabY + tabH, C_SEL);
            else if (hov) g.method_25294(tx, tabY, tx + tw, tabY + tabH, C_HOV);
            if (active)   g.method_25294(tx, tabY + tabH - 2, tx + tw, tabY + tabH, C_ACCENT);
            g.method_51433(field_22793, tabs[i], tx + 8, tabY + (tabH - 8) / 2, active ? C_TEXT : C_MUTED, false);
            tx += tw + 2;
        }

        // ── content area ────────────────────────────────────────────────────
        g.method_25294(px, contentY, px + pw, footerY, C_BG);
        g.method_25294(splitX, contentY, splitX + 1, footerY, C_BORDER);

        renderSearchCol(g, mx, my, delta);
        renderListCol(g, mx, my);

        // ── footer ──────────────────────────────────────────────────────────
        g.method_25294(px, footerY, px + pw, footerY + 1, C_BORDER);
        g.method_25294(px, footerY + 1, px + pw, py + ph, C_HEADER);
        int cx = px + pw / 2;
        boolean fHov = mx >= cx - 32 && mx < cx + 32 && my >= footerY && my < footerY + footerH;
        if (fHov) g.method_25294(cx - 32, footerY + 5, cx + 32, footerY + footerH - 5, 0xFF1C2128);
        g.method_25300(field_22793, "close", cx, footerY + (footerH - 8) / 2, fHov ? C_TEXT : C_MUTED);

        // ── picker overlay ──────────────────────────────────────────────────
        if (pickerTarget != null) renderPicker(g, mx, my);
    }

    private void renderFeatureRow(class_332 g, int mx, int my, int y,
                                   String label, float anim, boolean on, int color, String pickerId) {
        boolean hov = mx >= px && mx < px + pw && my >= y && my < y + FEAT_H;
        if (hov) g.method_25294(px, y, px + pw, y + FEAT_H, C_HOV);
        g.method_25294(px, y + FEAT_H - 1, px + pw, y + FEAT_H, C_BORDER);

        g.method_51433(field_22793, label, px + PAD, y + (FEAT_H - 8) / 2, on ? C_TEXT : C_MUTED, false);

        // pill toggle
        int pillX = px + pw - PAD - PILL_W;
        int pillY = y + (FEAT_H - PILL_H) / 2;
        int pillColor = lerpRgb(0xFF30363D, C_GREEN, anim);
        drawPill(g, pillX, pillY, PILL_W, PILL_H, pillColor);
        int knobSize = PILL_H - 4;
        int knobX = pillX + 2 + (int)((PILL_W - PILL_H) * anim);
        drawPill(g, knobX, pillY + 2, knobSize, knobSize, 0xFFFFFFFF);

        // color swatch
        if (color >= 0 && pickerId != null) {
            int sx = pillX - 8 - SWATCH;
            int sy = y + (FEAT_H - SWATCH) / 2;
            if ("playerGlow".equals(pickerId)) swatchPlayerX = sx;
            if ("mobGlow".equals(pickerId))    swatchMobX    = sx;
            boolean swHov = pickerTarget == null && mx >= sx - 2 && mx < sx + SWATCH + 2 && my >= sy - 2 && my < sy + SWATCH + 2;
            g.method_25294(sx - 1, sy - 1, sx + SWATCH + 1, sy + SWATCH + 1, C_BORDER);
            g.method_25294(sx, sy, sx + SWATCH, sy + SWATCH, color | 0xFF000000);
            if (swHov || pickerId.equals(pickerTarget)) g.method_25294(sx - 2, sy - 2, sx + SWATCH + 2, sy + SWATCH + 2, 0x33FFFFFF);
        }
    }

    // Pixel-art rasterized rounded rectangle (approximates pill/circle shapes)
    private static void drawPill(class_332 g, int x, int y, int w, int h, int color) {
        if (w <= 0 || h <= 0) return;
        int r = Math.min(h / 2, w / 2);
        // center rectangle (no corners)
        g.method_25294(x + r, y, x + w - r, y + h, color);
        // left/right caps drawn as stacked horizontal segments
        for (int row = 0; row < h; row++) {
            float dy = row - (h - 1) / 2f;
            float capWidth = (float) Math.sqrt(Math.max(0, r * r - dy * dy));
            int left  = (int)(r - capWidth);
            int right = (int)(r - capWidth);
            g.method_25294(x + left, y + row, x + r, y + row + 1, color);
            g.method_25294(x + w - r, y + row, x + w - right, y + row + 1, color);
        }
    }

    private void renderSearchCol(class_332 g, int mx, int my, float delta) {
        int colW = splitX - px;
        int sbBgY = contentY + 5;

        g.method_25294(px + PAD, sbBgY, splitX - PAD, sbBgY + 22, C_SURFACE);
        g.method_25294(px + PAD, sbBgY + 21, splitX - PAD, sbBgY + 22, searchBox.method_25370() ? C_ACCENT : C_BORDER);

        if (searchBox.method_1882().isEmpty()) {
            g.method_51433(field_22793, mobMode ? "Search mobs..." : "Search blocks...", px + PAD + 6, sbBgY + 7, C_DIM_TXT, false);
        }
        searchBox.method_46421(px + PAD + 6);
        searchBox.method_46419(sbBgY + 6);
        searchBox.method_25358(colW - PAD * 2 - 12);
        searchBox.method_25394(g, mx, my, delta);

        List<?> results = mobMode ? mobResults : blockResults;
        if (!results.isEmpty()) {
            int listY = sbBgY + 28;
            int listH = contentH - 34;
            int y = listY;
            for (int i = 0; i < results.size() && y + ROW_H <= listY + listH; i++, y += ROW_H) {
                String name = mobMode ? ((class_1299<?>)results.get(i)).method_5897().getString()
                                      : ((class_2248)results.get(i)).method_9518().getString();
                boolean sel = i == selectedResult;
                boolean hov = mx >= px && mx < splitX && my >= y && my < y + ROW_H;
                if (sel) {
                    g.method_25294(px + PAD - 2, y, splitX - PAD + 2, y + ROW_H - 2, 0xFF1C2128);
                    g.method_25294(px + PAD - 2, y + 2, px + PAD, y + ROW_H - 4, C_ACCENT);
                } else if (hov) {
                    g.method_25294(px, y, splitX, y + ROW_H - 1, C_HOV);
                }
                g.method_51433(field_22793, name, px + PAD + 6, y + (ROW_H - 8) / 2, sel || hov ? C_TEXT : C_MUTED, false);
            }
        } else if (!searchBox.method_1882().isEmpty()) {
            g.method_51433(field_22793, "no results", px + PAD + 4, contentY + 36, C_DIM_TXT, false);
        }
    }

    private void renderListCol(class_332 g, int mx, int my) {
        List<String> list = whitelistCache;
        int vis = Math.max(1, contentH / ROW_H);
        listScroll = Math.min(listScroll, Math.max(0, list.size() - vis));

        int x0 = splitX + 1;
        int colW = px + pw - x0;
        boolean hasScroll = list.size() > vis;
        int textMaxW = colW - PAD * 2 - (mobMode ? 0 : SWATCH + 6) - 20 - (hasScroll ? 10 : 0);

        if (list.isEmpty()) {
            g.method_51433(field_22793, "nothing added yet", x0 + PAD, contentY + 10, C_DIM_TXT, false);
            return;
        }

        int y = contentY + 4;
        for (int i = listScroll; i < list.size() && y + ROW_H <= contentY + contentH; i++, y += ROW_H) {
            String id   = list.get(i);
            String name = nameCache.getOrDefault(id, id);
            boolean hov = mx >= x0 && mx < x0 + colW && my >= y && my < y + ROW_H;
            if (hov) g.method_25294(x0, y, x0 + colW, y + ROW_H - 1, C_HOV);

            int removeX = x0 + colW - PAD - (hasScroll ? 10 : 0) - 6;
            boolean btnHov = mx >= removeX - 2 && mx < removeX + 8 && my >= y && my < y + ROW_H;

            int textX = x0 + PAD;
            if (!mobMode) {
                int c = colorCache.getOrDefault(id, 0x00FF00) | 0xFF000000;
                int sx = x0 + PAD, sy = y + (ROW_H - SWATCH) / 2;
                boolean swHov = mx >= sx - 2 && mx < sx + SWATCH + 2 && my >= sy - 2 && my < sy + SWATCH + 2;
                g.method_25294(sx - 1, sy - 1, sx + SWATCH + 1, sy + SWATCH + 1, C_BORDER);
                g.method_25294(sx, sy, sx + SWATCH, sy + SWATCH, c);
                if (swHov || id.equals(pickerTarget)) g.method_25294(sx - 2, sy - 2, sx + SWATCH + 2, sy + SWATCH + 2, 0x33FFFFFF);
                textX = sx + SWATCH + 5;
            }
            String disp = field_22793.method_1727(name) > textMaxW ? field_22793.method_27523(name, textMaxW - 6) + "…" : name;
            g.method_51433(field_22793, disp, textX, y + (ROW_H - 8) / 2, hov ? C_TEXT : C_MUTED, false);
            g.method_51433(field_22793, "✕", removeX, y + (ROW_H - 8) / 2, btnHov ? C_RED : C_DIM_TXT, false);
        }

        if (hasScroll) {
            int sbX = x0 + colW - 4;
            int totalH = contentH - 4;
            int thumbH = Math.max(8, totalH * vis / list.size());
            int thumbY = contentY + 4 + (totalH - thumbH) * listScroll / Math.max(1, list.size() - vis);
            g.method_25294(sbX, contentY + 4, sbX + 2, contentY + 4 + totalH, C_BORDER);
            g.method_25294(sbX, thumbY, sbX + 2, thumbY + thumbH, 0xFF484F58);
        }
    }

    private void renderPicker(class_332 g, int mx, int my) {
        // card
        g.method_25294(pkX + 2, pkY + 2, pkX + PK_W + 2, pkY + PK_H + 2, 0x44000000);
        g.method_25294(pkX - 1, pkY - 1, pkX + PK_W + 1, pkY + PK_H + 1, C_BORDER);
        g.method_25294(pkX, pkY, pkX + PK_W, pkY + PK_H, C_SURFACE);

        int svX = pkX + PK_PAD, svY = pkY + PK_PAD;

        // SV square
        float[] hr = hsvToRgb(pickerH, 1f, 1f);
        for (int col = 0; col < PK_SIZE; col++) {
            float s = (float) col / (PK_SIZE - 1);
            int top = 0xFF000000
                | ((int)((1f + (hr[0] - 1f) * s) * 255) << 16)
                | ((int)((1f + (hr[1] - 1f) * s) * 255) << 8)
                | (int)((1f + (hr[2] - 1f) * s) * 255);
            g.method_25296(svX + col, svY, svX + col + 1, svY + PK_SIZE, top, 0xFF000000);
        }

        // SV crosshair
        int cx = svX + Math.round(pickerS * (PK_SIZE - 1));
        int cy = svY + Math.round((1f - pickerV) * (PK_SIZE - 1));
        g.method_25294(cx - 4, cy - 1, cx + 4, cy + 1, 0xFFFFFFFF);
        g.method_25294(cx - 1, cy - 4, cx + 1, cy + 4, 0xFFFFFFFF);
        g.method_25294(cx - 3, cy - 1, cx + 3, cy + 1, 0xFF000000);
        g.method_25294(cx - 1, cy - 3, cx + 1, cy + 3, 0xFF000000);

        // hue bar
        int hueY = svY + PK_SIZE + PK_PAD;
        for (int col = 0; col < PK_SIZE; col++) {
            float[] c = hsvToRgb((float) col / PK_SIZE, 1f, 1f);
            g.method_25294(svX + col, hueY, svX + col + 1, hueY + PK_HUE_H,
                    0xFF000000 | ((int)(c[0]*255) << 16) | ((int)(c[1]*255) << 8) | (int)(c[2]*255));
        }
        int hx = svX + Math.round(pickerH * (PK_SIZE - 1));
        g.method_25294(hx - 1, hueY - 2, hx + 1, hueY + PK_HUE_H + 2, 0xFFFFFFFF);

        // preview + hex
        int pY = hueY + PK_HUE_H + PK_PAD;
        int cur = hsvToInt(pickerH, pickerS, pickerV);
        g.method_25294(svX - 1, pY - 1, svX + 17, pY + 13, C_BORDER);
        g.method_25294(svX, pY, svX + 16, pY + 12, cur);
        g.method_51433(field_22793, String.format("#%06X", cur & 0xFFFFFF), svX + 22, pY + 2, C_MUTED, false);
    }

    // ── color helpers ─────────────────────────────────────────────────────

    private static float[] rgbToHsv(int rgb) {
        float r=((rgb>>16)&0xFF)/255f, g=((rgb>>8)&0xFF)/255f, b=(rgb&0xFF)/255f;
        float max=Math.max(r,Math.max(g,b)), min=Math.min(r,Math.min(g,b)), d=max-min;
        float h=0, s=max==0?0:d/max, v=max;
        if (d!=0) {
            if (max==r) h=(g-b)/d+(g<b?6:0);
            else if (max==g) h=(b-r)/d+2;
            else h=(r-g)/d+4;
            h/=6f;
        }
        return new float[]{h,s,v};
    }

    private static int hsvToInt(float h, float s, float v) {
        float[] c=hsvToRgb(h,s,v);
        return 0xFF000000|((int)(c[0]*255)<<16)|((int)(c[1]*255)<<8)|(int)(c[2]*255);
    }

    private static float[] hsvToRgb(float h, float s, float v) {
        if (s==0) return new float[]{v,v,v};
        float hh=h*6; int i=(int)hh; float f=hh-i;
        float p=v*(1-s),q=v*(1-f*s),t=v*(1-(1-f)*s);
        return switch(i%6){
            case 0->new float[]{v,t,p}; case 1->new float[]{q,v,p};
            case 2->new float[]{p,v,t}; case 3->new float[]{p,q,v};
            case 4->new float[]{t,p,v}; default->new float[]{v,p,q};
        };
    }

    private static int lerpRgb(int a, int b, float t) {
        int ar=(a>>16)&0xFF,ag=(a>>8)&0xFF,ab=a&0xFF;
        int br=(b>>16)&0xFF,bg=(b>>8)&0xFF,bb=b&0xFF;
        return 0xFF000000|((int)(ar+(br-ar)*t)<<16)|((int)(ag+(bg-ag)*t)<<8)|(int)(ab+(bb-ab)*t);
    }

    private void openPicker(String id, int color, int ax, int ay) {
        pickerTarget=id;
        float[] hsv=rgbToHsv(color&0xFFFFFF);
        pickerH=hsv[0]; pickerS=hsv[1]; pickerV=hsv[2];
        pkX=Math.max(4,Math.min(ax, field_22789-PK_W-4));
        pkY=Math.max(4,Math.min(ay, field_22790-PK_H-4));
    }

    private void applyPicker() {
        if (pickerTarget==null) return;
        int color=hsvToInt(pickerH,pickerS,pickerV)&0xFFFFFF;
        switch (pickerTarget) {
            case "playerGlow" -> { GlowConfig.playerGlowColor=color; GlowConfig.save(); }
            case "mobGlow"    -> { GlowConfig.mobGlowColor   =color; GlowConfig.save(); }
            default -> { GlowConfig.blockWhitelist.put(pickerTarget,color); GlowConfig.save(); BlockOutlineRenderer.rescanAll(); rebuildCache(); }
        }
    }

    // ── data ──────────────────────────────────────────────────────────────

    private void refreshResults(String query) {
        String q=query.toLowerCase().trim();
        if (q.isEmpty()) { blockResults=new ArrayList<>(); mobResults=new ArrayList<>(); return; }
        if (mobMode) {
            mobResults=StreamSupport.stream(class_7923.field_41177.spliterator(),false)
                .filter(et->et.method_5891()!=class_1311.field_17715)
                .filter(et->{class_2960 id=class_7923.field_41177.method_10221(et); if(id==null) return false;
                    if(GlowConfig.mobGlowWhitelist.contains(id.toString())) return false;
                    return id.toString().contains(q)||et.method_5897().getString().toLowerCase().contains(q);
                }).limit(MAX_RES).toList();
        } else {
            blockResults=StreamSupport.stream(class_7923.field_41175.spliterator(),false)
                .filter(b->{class_2960 id=class_7923.field_41175.method_10221(b); if(id==null) return false;
                    if(GlowConfig.blockWhitelist.containsKey(id.toString())) return false;
                    return id.toString().contains(q)||b.method_9518().getString().toLowerCase().contains(q);
                }).limit(MAX_RES).toList();
        }
    }

    private void addBlock(class_2248 block) {
        class_2960 id=class_7923.field_41175.method_10221(block); if(id==null) return;
        if(!GlowConfig.blockWhitelist.containsKey(id.toString())) {
            GlowConfig.blockWhitelist.put(id.toString(),GlowConfig.defaultOutlineColor);
            GlowConfig.save(); BlockOutlineRenderer.rescanAll(); rebuildCache();
        }
        searchBox.method_1852(""); blockResults=new ArrayList<>(); selectedResult=0;
    }

    private void addMob(class_1299<?> et) {
        class_2960 id=class_7923.field_41177.method_10221(et); if(id==null) return;
        if(GlowConfig.mobGlowWhitelist.add(id.toString())) { GlowConfig.save(); rebuildCache(); }
        searchBox.method_1852(""); mobResults=new ArrayList<>(); selectedResult=0;
    }

    private void addFromInput() {
        if (mobMode) {
            if(!mobResults.isEmpty()) addMob(mobResults.get(Math.min(selectedResult,mobResults.size()-1)));
        } else {
            if(!blockResults.isEmpty()) { addBlock(blockResults.get(Math.min(selectedResult,blockResults.size()-1))); return; }
            String t=searchBox.method_1882().trim();
            class_2960 id=class_2960.method_12829(t);
            if(id!=null) { class_2248 b=class_7923.field_41175.method_63535(id); if(b!=null) addBlock(b); }
        }
    }

    private void removeEntry(String id) {
        if(mobMode) GlowConfig.mobGlowWhitelist.remove(id);
        else { GlowConfig.blockWhitelist.remove(id); BlockOutlineRenderer.rescanAll(); }
        GlowConfig.save(); rebuildCache();
        listScroll=Math.min(listScroll,Math.max(0,whitelistCache.size()-Math.max(1,contentH/ROW_H)));
    }

    private void switchTab(boolean mobs) {
        if(mobMode==mobs) return;
        mobMode=mobs; selectedResult=0; listScroll=0;
        searchBox.method_1852(""); blockResults=new ArrayList<>(); mobResults=new ArrayList<>();
        rebuildCache();
    }

    private void rebuildCache() {
        nameCache.clear(); colorCache.clear();
        if (mobMode) {
            whitelistCache=new ArrayList<>(GlowConfig.mobGlowWhitelist);
            for(String id:whitelistCache) {
                class_2960 p=class_2960.method_12829(id);
                class_1299<?> et=p!=null?class_7923.field_41177.method_63535(p):null;
                nameCache.put(id,et!=null?et.method_5897().getString():id);
            }
        } else {
            whitelistCache=new ArrayList<>(GlowConfig.blockWhitelist.keySet());
            for(String id:whitelistCache) {
                class_2960 p=class_2960.method_12829(id);
                class_2248 b=p!=null?class_7923.field_41175.method_63535(p):null;
                nameCache.put(id,b!=null?b.method_9518().getString():id);
                colorCache.put(id,GlowConfig.blockWhitelist.getOrDefault(id,GlowConfig.defaultOutlineColor));
            }
        }
    }

    private String keyName() {
        return KeyBindingHelper.getBoundKeyOf(GlowModClient.openGuiKey).method_27445().getString();
    }

    // ── input ─────────────────────────────────────────────────────────────

    @Override
    public boolean method_25402(net.minecraft.class_11909 event, boolean captured) {
        if(captured||event.method_74245()!=0) return super.method_25402(event,captured);
        int mx=(int)event.comp_4798(), my=(int)event.comp_4799();

        if(capturingKey) { capturingKey=false; return true; }

        if(pickerTarget!=null) {
            int svX=pkX+PK_PAD, svY=pkY+PK_PAD, hueY=svY+PK_SIZE+PK_PAD;
            if(mx>=svX&&mx<=svX+PK_SIZE&&my>=svY&&my<=svY+PK_SIZE) {
                dragSV=true;
                pickerS=Math.max(0f,Math.min(1f,(float)(mx-svX)/PK_SIZE));
                pickerV=Math.max(0f,Math.min(1f,1f-(float)(my-svY)/PK_SIZE));
                applyPicker(); return true;
            }
            if(mx>=svX&&mx<=svX+PK_SIZE&&my>=hueY&&my<=hueY+PK_HUE_H) {
                dragHue=true;
                pickerH=Math.max(0f,Math.min(1f,(float)(mx-svX)/PK_SIZE));
                applyPicker(); return true;
            }
            if(mx<pkX||mx>pkX+PK_W||my<pkY||my>pkY+PK_H) { pickerTarget=null; return true; }
            return true;
        }

        if(mx>=keyBtnX&&mx<keyBtnX+keyBtnW&&my>=keyBtnY&&my<keyBtnY+16) { capturingKey=true; return true; }

        int pillX=px+pw-PAD-PILL_W;
        int swatchX=pillX-8-SWATCH;
        for(int i=0;i<3;i++) {
            int ry=(i==0?rowPlayerY:i==1?rowMobY:rowOutlineY);
            if(my<ry||my>=ry+FEAT_H) continue;
            int sy=ry+(FEAT_H-SWATCH)/2;
            if(i==0) {
                if(mx>=swatchX-2&&mx<swatchX+SWATCH+2&&my>=sy-2&&my<sy+SWATCH+2) { openPicker("playerGlow",GlowConfig.playerGlowColor,mx,my+14); return true; }
                GlowConfig.playerGlowEnabled=!GlowConfig.playerGlowEnabled; GlowConfig.save(); return true;
            } else if(i==1) {
                if(mx>=swatchX-2&&mx<swatchX+SWATCH+2&&my>=sy-2&&my<sy+SWATCH+2) { openPicker("mobGlow",GlowConfig.mobGlowColor,mx,my+14); return true; }
                GlowConfig.mobGlowEnabled=!GlowConfig.mobGlowEnabled; GlowConfig.save(); return true;
            } else {
                GlowConfig.blockOutlineEnabled=!GlowConfig.blockOutlineEnabled; GlowConfig.save(); return true;
            }
        }

        if(my>=tabY&&my<tabY+tabH) {
            int tx=px+PAD; int tw0=field_22793.method_1727("blocks")+16;
            if(mx>=tx&&mx<tx+tw0) { switchTab(false); return true; }
            tx+=tw0+2;
            if(mx>=tx&&mx<tx+field_22793.method_1727("mobs")+16) { switchTab(true); return true; }
        }

        int sbBgY=contentY+5;
        int listY0=sbBgY+28, listH=contentH-34;
        if(mx>=px&&mx<splitX&&my>=listY0&&my<listY0+listH) {
            int row=(my-listY0)/ROW_H;
            if(mobMode&&row>=0&&row<mobResults.size())    { addMob(mobResults.get(row));    return true; }
            if(!mobMode&&row>=0&&row<blockResults.size()) { addBlock(blockResults.get(row)); return true; }
        }

        int x0=splitX+1, colW2=px+pw-x0;
        boolean hasScroll=whitelistCache.size()>Math.max(1,contentH/ROW_H);
        int y=contentY+4;
        for(int i=listScroll;i<whitelistCache.size()&&y+ROW_H<=contentY+contentH;i++,y+=ROW_H) {
            if(my<y||my>=y+ROW_H||mx<x0||mx>=x0+colW2) continue;
            int removeX=x0+colW2-PAD-(hasScroll?10:0)-6;
            if(mx>=removeX-2) { removeEntry(whitelistCache.get(i)); return true; }
            if(!mobMode) {
                int sx=x0+PAD, sy=y+(ROW_H-SWATCH)/2;
                if(mx>=sx-2&&mx<sx+SWATCH+2&&my>=sy-2&&my<sy+SWATCH+2) {
                    openPicker(whitelistCache.get(i),colorCache.getOrDefault(whitelistCache.get(i),GlowConfig.defaultOutlineColor),mx,my+10);
                    return true;
                }
            }
            return true;
        }

        int cx=px+pw/2;
        if(mx>=cx-32&&mx<cx+32&&my>=footerY&&my<footerY+footerH) { method_25419(); return true; }
        return super.method_25402(event,captured);
    }

    @Override
    public boolean method_25403(net.minecraft.class_11909 event,double dx,double dy) {
        if(event.method_74245()!=0) return super.method_25403(event,dx,dy);
        double mx=event.comp_4798(),my=event.comp_4799();
        if(dragSV) {
            pickerS=Math.max(0f,Math.min(1f,(float)(mx-(pkX+PK_PAD))/PK_SIZE));
            pickerV=Math.max(0f,Math.min(1f,1f-(float)(my-(pkY+PK_PAD))/PK_SIZE));
            applyPicker(); return true;
        }
        if(dragHue) {
            pickerH=Math.max(0f,Math.min(1f,(float)(mx-(pkX+PK_PAD))/PK_SIZE));
            applyPicker(); return true;
        }
        return super.method_25403(event,dx,dy);
    }

    @Override
    public boolean method_25406(net.minecraft.class_11909 event) {
        dragSV=false; dragHue=false; return super.method_25406(event);
    }

    @Override
    public boolean method_25401(double mx,double my,double sx,double sy) {
        if(mx>=splitX&&mx<px+pw&&my>=contentY&&my<contentY+contentH) {
            int vis=Math.max(1,contentH/ROW_H);
            listScroll=Math.max(0,Math.min(listScroll+(sy>0?-1:1),Math.max(0,whitelistCache.size()-vis)));
            return true;
        }
        if(mx>=px&&mx<splitX&&my>=contentY+28&&my<contentY+contentH) {
            int size=mobMode?mobResults.size():blockResults.size();
            selectedResult=Math.max(0,Math.min(selectedResult+(sy>0?-1:1),size-1));
            return true;
        }
        return super.method_25401(mx,my,sx,sy);
    }

    @Override
    public boolean method_25404(class_11908 event) {
        int k=event.comp_4795();
        if(capturingKey) {
            if(k==GLFW.GLFW_KEY_ESCAPE) { capturingKey=false; return true; }
            GlowModClient.openGuiKey.method_1422(class_3675.class_307.field_1668.method_1447(k));
            class_304.method_1426();
            assert field_22787!=null; field_22787.field_1690.method_1640();
            capturingKey=false; return true;
        }
        if(k==GLFW.GLFW_KEY_ESCAPE) { if(pickerTarget!=null){pickerTarget=null;return true;} method_25419(); return true; }
        if(k==GLFW.GLFW_KEY_ENTER||k==GLFW.GLFW_KEY_KP_ENTER) { addFromInput(); return true; }
        int size=mobMode?mobResults.size():blockResults.size();
        if(k==GLFW.GLFW_KEY_UP)   { selectedResult=Math.max(0,selectedResult-1); return true; }
        if(k==GLFW.GLFW_KEY_DOWN) { selectedResult=Math.min(size-1,selectedResult+1); return true; }
        return super.method_25404(event);
    }

    @Override
    public void method_25419() { assert field_22787!=null; field_22787.method_1507(parent); }
}
